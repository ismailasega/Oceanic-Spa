<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Oceanic Spa | Where your mind goes to rest</title>
<link rel="icon" type="image/x-png" href="images/logo header.png" />
<style type="text/css">
.booking {
	color: #FFF;
}
.home {
	color: #FF8000;
	font-family: "Comic Sans MS", cursive;
}
body {
	background-color: #523815;
}
</style>
</head>

<body>

<br />
<br />
<br />
<br />
<br />
<br />
<center>
<img src="../../01082017/HTC FLASH/Beauti Secrets &amp; ocenic spa - 0772544455/Oceanic Website/images/logo.jpg" />
  <br>
  <br>
  <span class="booking">Thank you for Booking an Appointment. We will be in touch with you very soon.</span><br><br />

<a href="index.html" class="home">HOME</a></center>

</body>
</html>