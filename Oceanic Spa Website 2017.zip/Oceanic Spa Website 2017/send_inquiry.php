<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Oceanic Spa | Where your mind goes to rest</title>
<link rel="icon" type="image/x-png" href="images/logo header.png" />
<style type="text/css">
.contactemail {
	color: #FFF;
}
.index {
	color: #FF8000;
	font-family: "Comic Sans MS", cursive;
}
body {
	background-color: #523815;
}
</style>
</head>

<body>
<?php
if(isset($_POST['email'])) {

    $email_to = "asega03@gmail.com";
    $email_subject = "Inquiry";

    $email_message = "Form details below.\n\n";

    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }

    $email_message .= "Name: ".clean_string($name)."\n";
    $email_message .= "Email: ".clean_string($email)."\n";
    $email_message .= "Telephone: ".clean_string($telephone)."\n";
    $email_message .= "Message: ".clean_string($message)."\n";


$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers); 
?>

<br />
<br />
<br />
<br />
<br />
<br />

<center>
<img src="../../01082017/HTC FLASH/Beauti Secrets &amp; ocenic spa - 0772544455/Oceanic Website/images/logo.jpg" />
  <br>
  <br>
  <span class="contactemail">Thank you for contacting us.  We will be in touch.</span><br>
<br><br />

<a href="index.html" class="index">HOME</a></center>

<?php
}
?>
</body>
</html>